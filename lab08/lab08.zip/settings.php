<?php
$host = "feenix-mariadb.swin.edu.au";
$user = "s103803891"; // your user name
$pswd = "301103"; // your password (date of birth – ddmmyy)
$dbnm = "s103803891_db"; // your database

// Connect to database
$conn = mysqli_connect($host, $user, $pswd, $dbnm);
?>