<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="description" content="Web application development" />
    <meta name="keywords" content="PHP" />
    <meta name="author" content="Tran Quoc Dung" />
    <title>Lab 04</title>
</head>

<body>
    <h1>Web Programming Form - Lab 4</h1>
    
    <form action = "strprocess.php" method = "post" >
    <label for="text">Text: </label>
    <input type="text" name="text" id="text" placeholder="Enter the string here..."><br>
    <button type="submit">Output</button>
</body>

</html>