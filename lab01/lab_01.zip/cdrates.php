<!DOCTYPE html>
    <html lang="en">
    <head>
    <title>CD Rates Webpage</title>
    <meta charset="utf-8">
    <meta name="description" content="Web development">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="author" content="your name">
</head>
<body>
    <h1>Forestville Credit Union</h1>
    <h2>CD Rates</h2>
    <?php
        /* Printing CD rate information as bullet points */
        echo "
        <ul>
            <li><p>4.35% (36-Month Term CD)</p></li>
            <li><p>3.85% (12-Month Term CD)</p></li>
            <li><p>2.65% (6-Month Term CD)</p></li>
        </ul>
        ";
         
        /* Printing paragraph element */
        echo "$1,000 minimum deposit";

        /* 103803891 Tran Quoc Dung (03-01-2024) */
    ?>
</body>
</html>